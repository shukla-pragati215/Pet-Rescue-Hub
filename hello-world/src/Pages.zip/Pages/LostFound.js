// LostFound.js
import React from "react";
import "./LostFound.css";
import { Link } from "react-router-dom";

function LostFound() {
  return (
    <div className="adopt-container">

      {/* Navbar */}
      <nav className="navbar">
        <div className="nav-left">
          <Link to="/">Home</Link>
          <Link to="/adopt">Adopt a Pet</Link>
          <Link to="/lost-found">Lost & Found</Link>
          <Link to="/pet-doctors">Pet Doctors</Link>
          <Link to="/pet-care">Pet Care</Link>
        </div>

        <div className="nav-right">
          <Link to="/login" className="login-link">Login</Link>
          <Link to="/signup" className="signup-btn">Sign Up</Link>
        </div>
      </nav>

      <div className="lostfound-container">

        {/* Header */}
        <header className="lostfound-header">
          <h1>🐾 PET RESCUE HUB</h1>
          <h2>Lost and Found Pets</h2>
          <p>
            Report or find lost pets in your area. Help reunite furry friends with
            their families.
          </p>
        </header>

        {/* Search & Filters */}
        <div className="lostfound-controls">
          <input
            type="text"
            placeholder="Search by name, breed, etc."
            className="search-bar"
          />
          <button className="report-btn">+ Report Lost Pet</button>
        </div>

        <div className="filters">
          <select>
            <option>Lost & Found</option>
            <option>Lost</option>
            <option>Found</option>
          </select>

          <select>
            <option>All Animals</option>
            <option>Dog</option>
            <option>Cat</option>
            <option>Rabbit</option>
          </select>

          <select>
            <option>All Locations</option>
            <option>Green Valley</option>
            <option>Downtown</option>
          </select>

          <select>
            <option>Date Posted</option>
            <option>Newest</option>
            <option>Oldest</option>
          </select>
        </div>

        {/* Pets Grid */}
        <div className="pets-grid">

          <div className="pet-card">
            <img src="dog1.jpg" alt="Max" />
            <h3>Max</h3>
            <p>Labrador Retriever Mix</p>
            <p>Green Valley</p>
            <button className="view-btn">View Details</button>
          </div>

          <div className="pet-card">
            <img src="cat.webp" alt="Bella" />
            <h3>Bella</h3>
            <p>Domestic Shorthair</p>
            <p>Green Valley</p>
            <button className="view-btn">View Details</button>
          </div>

          <div className="pet-card">
            <img src="dog4.jpeg" alt="Charlie" />
            <h3>Charlie</h3>
            <p>Australian Shepherd</p>
            <p>Downtown</p>
            <button className="view-btn">View Details</button>
          </div>

          <div className="pet-card">
            <img src="rabbit.jpg" alt="Daisy" />
            <h3>Daisy</h3>
            <p>Rabbit</p>
            <p>Green Valley</p>
            <button className="view-btn">View Details</button>
          </div>

        </div>

        {/* Footer */}
        <footer className="lostfound-footer">
          <a href="/">Home</a>
          <a href="/contact">Contact</a>
          <a href="/policy">Privacy Policy</a>
        </footer>

      </div>
    </div>
  );
}

export default LostFound;

import React from "react";
import "./PetDoctors.css";
import { Link } from "react-router-dom";

function PetDoctors() {
  return (
    <div className="adopt-container">
      {/* Navbar */}
      <nav className="navbar">
        <div className="nav-left">
          <Link to="/">Home</Link>
          <Link to="/adopt">Adopt a Pet</Link>
          <Link to="/lost-found">Lost & Found</Link>
          <Link to="/pet-doctors">Pet Doctors</Link>
          <Link to="/pet-care">Pet Care</Link>
        </div>

        <div className="nav-right">
          <Link to="/login" className="login-link">Login</Link>
          <Link to="/signup" className="signup-btn">Sign Up</Link>
        </div>
      </nav>

      {/* Main Content */}
      <div className="pet-doctors-container">
        {/* Header Section */}
        <header className="header">
          <h1>Pet Doctors</h1>
          <p>Find trusted veterinarians for your beloved pets</p>
        </header>

        {/* Doctors List Section */}
        <section className="doctors-list">
          <div className="doctor-card">
            <img src="doctor1.jpg" alt="Dr. John Smith" />
            <h3>Dr. John Smith</h3>
            <p>Specialist in Dogs & Cats</p>
            <button>Book Appointment</button>
          </div>

          <div className="doctor-card">
            <img src="doctor2.jpg" alt="Dr. Jane Doe" />
            <h3>Dr. Jane Doe</h3>
            <p>Exotic Pets Specialist</p>
            <button>Book Appointment</button>
          </div>

          <div className="doctor-card">
            <img src="doctor3.jpg" alt="Dr. Mark Wilson" />
            <h3>Dr. Mark Wilson</h3>
            <p>Surgeon & Emergency Care</p>
            <button>Book Appointment</button>
          </div>
        </section>

        {/* Footer */}
        <footer className="lostfound-footer">
          <a href="/">Home</a>
          <a href="/contact">Contact</a>
          <a href="/policy">Privacy Policy</a>
        </footer>
      </div>
    </div>
  );
}

export default PetDoctors;

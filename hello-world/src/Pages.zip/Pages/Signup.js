import React, { useState } from "react";
import "./Signup.css";
import { Link } from "react-router-dom";
import bg from "./pet-bg.webp";
import { FaFacebookF, FaTwitter, FaInstagram } from "react-icons/fa";


export default function SignupPage() {
  const [isSignup, setIsSignup] = useState(true);
  return (
         <div className="app-container" style={{ backgroundImage: `url(${bg})` }}>
    {/* Navbar */}
          <nav className="navbar">
            <div className="nav-left">
               <Link to="/">Home</Link>
                <Link to="/adopt">Adopt a Pet</Link>
                <Link to="/lost-found">Lost & Found</Link>
                <Link to="/pet-doctors">Pet Doctors</Link>
                <Link to="/pet-care">Pet Care</Link>
            </div>
          <div className="nav-right">
            <Link to="/login" className="login-link">Login</Link>
            <Link to="/signup" className="signup-btn">Sign Up</Link>
          </div>
          
                </nav>
    <div className="container">
      {/* Left Section */}
      <div className="left-section">
        <h1>
          Welcome to <br /> <span>Pet Rescue Hub!</span>
        </h1>
        <p>Join us in finding loving homes for pets in need.</p>
        <img
          src='dog.webp'
          alt="cute Dog"
          style={{ width: "300px", height: "350px", objectFit: "cover", borderRadius: "10px" }}
        />
      </div>
      {/* Right Section */}
      <div className="right-section">
        <h2>Pet Rescue Hub</h2>
        {/* Toggle Buttons */}
        <div className="tab-buttons">
          <button
            className={isSignup ? "active" : "inactive"}
            onClick={() => setIsSignup(true)}
          >
            Sign Up
          </button>
          <button
            className={!isSignup ? "active" : "inactive"}
            onClick={() => setIsSignup(false)}
          >
            Login
          </button>
          </div>
                  {/* Conditional Form */}
                  {isSignup ? (
                    <>
            <label>Name</label>
            <input type="text" placeholder="Enter your name" />

            <label>Email</label>
            <input type="email" placeholder="Enter your email" />

            <label>Password</label>
            <input type="password" placeholder="Create a password" />

            <button className="login-btn">Sign Up</button>
          </>
                  ):(
                     <>
            <label>Email</label>
            <input type="email" placeholder="Enter your email" />

            <label>Password</label>
            <input type="password" placeholder="Enter your password" />

            <button className="login-btn">Login</button>
          </>
                  )}
             {/* Extra Text */}
        {isSignup ? (
           <p className="signup-text">
            Already have an account?{" "}
            <span onClick={() => setIsSignup(false)}>Login</span>
          </p>
        ):(
          <p className="signup-text">
            Don't have an account?{" "}
            <span onClick={() => setIsSignup(true)}>Sign Up</span>
          </p> 
        )}
        </div>
        
        
        </div>
        <footer className="footer">
          <div className="footer-left">
            <h2 className="logo">
              🏠 Adopt a Pet <span>Powered by Pedigree</span>
            </h2>
            <p>©2023 Mars or Affiliates.</p>
            <div className="social-icons">
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer"><FaFacebookF /></a>
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer"><FaTwitter /></a>
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer"><FaInstagram /></a>
            </div>
          </div>
        
          {/* ✅ yaha pe galat `<` hata diya */}
          <div className="footer-links">
            <ul>
              <li><Link to="/home">Home</Link></li>
              <li><Link to="/adopt">Find a Pet</Link></li>
              <li><Link to="/faqs">Adoption Faqs</Link></li>
              <li><Link to="/follow-us">Follow Us</Link></li>
            </ul>
        
            <ul>
              <li><Link to="/partners">Partner Shelters & NGOs</Link></li>
              <li><Link to="/care">Caring For Pets</Link></li>
              <li><Link to="/about">About Us</Link></li>
            </ul>
        
            <ul>
              <li><Link to="/signup">Create an account</Link></li>
              <li><Link to="/login">Sign in</Link></li>
              <li><Link to="/contact">Contact Us</Link></li>
            </ul>
        
            <ul>
              <li><Link to="/mars">Visit Mars.com</Link></li>
              <li><Link to="/privacy">Privacy Statement</Link></li>
              <li><Link to="/legal">Legal</Link></li>
              <li><Link to="/ca-supply">CA Supply Chain Transparency Act</Link></li>
            </ul>
        
            <ul>
              <li><Link to="/modern-slavery">Modern Slavery Act</Link></li>
              <li><Link to="/accessibility">Accessibility</Link></li>
              <li><Link to="/cookies">Cookies Notice</Link></li>
              <li><Link to="/adchoices">AdChoices</Link></li>
            </ul>
          </div>
        
          <div className="cookie-btn">
            <button>Cookies Settings</button>
          </div>
        </footer>
        </div>
  );
}
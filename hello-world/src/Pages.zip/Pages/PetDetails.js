import React from "react";
import { useParams, Link } from "react-router-dom";
import "./PetDetails.css";

const pets = [
  { id: 1, name: "Bella", age: "2 years", breed: "Labrador", category: "Dog", image: "/images/dog1.jpg" },
  { id: 2, name: "Rocky", age: "1.5 years", breed: "Labrador", category: "Dog", image: "/images/dog2.jpg" },
  { id: 3, name: "Lucy", age: "3 years", breed: "Beagle", category: "Dog", image: "/images/dog3.jpg" },
  { id: 4, name: "Whiskers", age: "1 year", breed: "Persian Cat", category: "Cat", image: "/images/cat1.jpg" },
  { id: 5, name: "Snowy", age: "2.2 years", breed: "Persian Cat", category: "Cat", image: "/images/cat2.jpg" },
];

function PetDetails() {
  const { id } = useParams();
  const pet = pets.find((p) => p.id === Number(id));

  if (!pet) return <h2>Pet Not Found</h2>;

  // Find similar pets (same breed)
  const similarPets = pets.filter(
    (p) => p.breed === pet.breed && p.id !== pet.id
  );

  return (
    <div className="pet-page">

      {/* LEFT: PET IMAGE */}
      <div className="pet-left">
        <img src={pet.image} alt={pet.name} className="pet-main-img" />
      </div>

      {/* RIGHT: PET DETAILS */}
      <div className="pet-right">
        <h1>{pet.name}</h1>
        <p><strong>Age:</strong> {pet.age}</p>
        <p><strong>Breed:</strong> {pet.breed}</p>
        <p><strong>Category:</strong> {pet.category}</p>

        <h2>About {pet.name}</h2>
        <p className="pet-desc">
          {pet.name} is very friendly and loves humans. Perfect for families and safe with kids.
          Fully vaccinated and healthy.
        </p>

        <button className="adopt-btn">Adopt Now</button>
      </div>

      {/* SIMILAR PETS SECTION */}
      <div className="similar-section">
        <h2>Similar Pets</h2>

        <div className="similar-container">
          {similarPets.length > 0 ? (
            similarPets.map((sp) => (
              <Link to={`/pet-details/${sp.id}`} key={sp.id} className="similar-card">
                <img src={sp.image} alt={sp.name} />
                <h4>{sp.name}</h4>
                <p>{sp.age}</p>
              </Link>
            ))
          ) : (
            <p>No similar pets available.</p>
          )}
        </div>
      </div>
    </div>
  );
}

export default PetDetails;

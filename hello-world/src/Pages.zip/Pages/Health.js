import React from "react";
import { Link } from "react-router-dom";
import "./Health.css";

function Health() {
  return (
    <div className="adopt-container">

      {/* Navbar */}
      <nav className="navbar">
        <div className="nav-left">
          <Link to="/">Home</Link>
          <Link to="/adopt">Adopt a Pet</Link>
          <Link to="/lost-found">Lost & Found</Link>
          <Link to="/pet-doctors">Pet Doctors</Link>
          <Link to="/pet-care">Pet Care</Link>
        </div>

        <div className="nav-right">
          <Link to="/login" className="login-link">Login</Link>
          <Link to="/signup" className="signup-btn">Sign Up</Link>
        </div>
      </nav>

      <div className="health-container">

        {/* Header */}
        <h1 className="title">Pet Health</h1>
        <p className="subtitle">Preventive care and medical check-ups for pets</p>

        {/* Image */}
        <div className="image-container">
          <img src="vet.jpg" alt="Pet Health" className="health-image" />
        </div>

        {/* Info Section */}
        <div className="health-info">
          <h2>💙 Why Health Care Matters?</h2>
          <p>
            Regular health check-ups, vaccinations, and preventive care ensure your pet
            stays healthy, happy, and lives a longer life.
          </p>

          <h2>🩺 Preventive Care</h2>
          <ul>
            <li>💉 Timely vaccinations to prevent diseases</li>
            <li>🧪 Regular deworming to keep them parasite-free</li>
            <li>🐾 Flea and tick prevention treatments</li>
            <li>🥩 Balanced diet for strong immunity</li>
            <li>🏥 Annual vet check-ups</li>
          </ul>

          <h2>⚠️ Common Health Issues</h2>
          <ul>
            <li>🐶 Dogs – Obesity, ear infections, arthritis</li>
            <li>🐱 Cats – Dental disease, kidney problems, obesity</li>
            <li>🐇 Rabbits – Digestive issues, overgrown teeth</li>
            <li>🐦 Birds – Feather plucking, respiratory infections</li>
          </ul>

          <h2>📅 Health Check-up Schedule</h2>
          <table className="health-table">
            <thead>
              <tr>
                <th>Pet Age</th>
                <th>Check-up Frequency</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Puppies/Kittens</td>
                <td>Every 3–4 weeks until 16 weeks old</td>
              </tr>
              <tr>
                <td>Adult Pets</td>
                <td>Once a year</td>
              </tr>
              <tr>
                <td>Senior Pets</td>
                <td>Twice a year</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Videos Section */}
      <div className="video-section">
        <h2>🎥 Videos & Guides</h2>
        <p>Learn pet care techniques with these helpful videos</p>

        <div className="video-container">
          <div className="video-card">
            <iframe
              width="100%"
              height="250"
              src="https://www.youtube.com/embed/1zRrmFvZ2YQ"
              title="Pet Grooming Guide"
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            ></iframe>
            <h4>Dog Grooming Basics</h4>
          </div>

          <div className="video-card">
            <iframe
              width="100%"
              height="250"
              src="https://www.youtube.com/embed/BWnIbZfCY40"
              title="Pet First Aid"
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            ></iframe>
            <h4>Pet First Aid Tips</h4>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="lostfound-footer">
        <Link to="/">Home</Link>
        <Link to="/contact">Contact</Link>
        <Link to="/policy">Privacy Policy</Link>
      </footer>

    </div>
  );
}

export default Health;

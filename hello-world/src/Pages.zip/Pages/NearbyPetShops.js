// NearbyPetShops.js
import React, { useEffect, useRef } from "react";
import "./NearbyPetShops.css";

const shops = [
  { id: 1, name: "Pet Zone", lat: 19.295, lng: 72.854, address: "Mira Road" },
  { id: 2, name: "Paws & Claws", lat: 19.300, lng: 72.860, address: "Thane" },
];

function NearbyPetShops() {
  const mapRef = useRef(null);

  useEffect(() => {
    const initMap = () => {
      const map = new window.google.maps.Map(mapRef.current, {
        center: { lat: shops[0].lat, lng: shops[0].lng },
        zoom: 14,
      });

      shops.forEach((shop) => {
        new window.google.maps.Marker({
          position: { lat: shop.lat, lng: shop.lng },
          map,
          title: shop.name,
        });
      });
    };

    if (!window.google) {
      const script = document.createElement("script");
      script.src =
        "https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&callback=initMap";
      script.async = true;
      window.initMap = initMap;
      document.body.appendChild(script);
    } else {
      initMap();
    }
  }, []);

  return (
    <div className="map-page">
      <h2>Nearby Pet Shops</h2>
      <div ref={mapRef} className="map-container"></div>
    </div>
  );
}

export default NearbyPetShops;

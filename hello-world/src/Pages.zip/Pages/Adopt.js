// Adopt.js
import React, { useState } from "react";
import "./Adopt.css";
import { Link } from "react-router-dom";
import SubmitInterestForm from "./SubmitInterestForm";
import { FaFacebookF, FaTwitter, FaInstagram } from "react-icons/fa";

function Adopt() {
  const [showFindPetPopup, setShowFindPetPopup] = useState(false);
  const [showInterestForm, setShowInterestForm] = useState(false);

  return (
    <div className="adopt-container">
      {/* Navbar */}
      <nav className="navbar">
        <div className="nav-left">
          <Link to="/">Home</Link>
          <Link to="/adopt">Adopt a Pet</Link>
          <Link to="/lost-found">Lost & Found</Link>
          <Link to="/pet-doctors">Pet Doctors</Link>
          <Link to="/pet-care">Pet Care</Link>
        </div>

        <div className="nav-right">
          <Link to="/login" className="login-link">Login</Link>
          <Link to="/signup" className="signup-btn">Sign Up</Link>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="adopt-hero">
        <div className="hero-left">
          <h1>Welcome to Pet Rescue Hub</h1>
          <p>helping every paw find a home</p>
          <div className="hero-buttons">
            <Link to="/View-Pets">
              <button className="view-btn">View Pets</button>
            </Link>
            <Link to="/Adoption">
              <button className="adopt-btn">Adopt Now</button>
            </Link>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="categories">
        <h2>Rescue Pet Categories</h2>
        <div className="category-grid">

          {/* Find Pet */}
          <div className="category-card" onClick={() => setShowFindPetPopup(true)}>
            <img src="https://img.icons8.com/ios/100/dog.png" alt="Find a pet" />
            <h3>Find a pet</h3>
          </div>

          {/* Submit Interest Form */}
          <div className="category-card" onClick={() => setShowInterestForm(true)}>
            <img src="https://img.icons8.com/ios/100/form.png" alt="Submit form" />
            <h3>Submit interest form</h3>
          </div>

          {/* Adopt With Love */}
          <div className="category-card">
            <Link to="/adopt-with-love" style={{ textDecoration: "none", color: "inherit" }}>
              <img src="https://img.icons8.com/ios/100/like--v1.png" alt="Adopt with Love" />
              <h3>Adopt with Love</h3>
            </Link>
          </div>

        </div>
      </section>

      {/* Find Pet Popup */}
      {showFindPetPopup && (
        <div className="popup-overlay">
          <div className="popup-content">
            <div className="popup-header">
              <h2>Find a Pet</h2>
              <button className="close-btn" onClick={() => setShowFindPetPopup(false)}>×</button>
            </div>

            <form className="find-pet-form" onSubmit={(e) => e.preventDefault()}>
              <div className="form-group">
                <label>Location</label>
                <input type="text" placeholder="Enter location" />
              </div>

              <div className="form-group">
                <label>Pet Type</label>
                <input type="text" placeholder="e.g. Dog, Cat" />
              </div>

              <div className="form-group">
                <label>Breed</label>
                <input type="text" placeholder="Enter breed" />
              </div>

              <button type="submit" className="search-btn">Search</button>
            </form>
          </div>
        </div>
      )}

      {/* Submit Interest Form Popup */}
      {showInterestForm && (
        <div className="popup-overlay">
          <div className="popup-content">
            <SubmitInterestForm onClose={() => setShowInterestForm(false)} />
          </div>
        </div>
      )}

      {/* Available Pets */}
      <section className="available-pets">
        <h2>Available Pets</h2>
        <div className="pets-grid">
          <div className="pet-card">
            <img src="123.jpeg" alt="Bella" />
            <h3>Bella</h3>
            <p>2 years old</p>
  <button className="adopt-btn">Adopt</button>

          </div>

          <div className="pet-card">
            <img src="567.jpeg" alt="Max" />
            <h3>Max</h3>
            <p>3 years old, Labrador mix</p>
            <Link>
            <button className="adopt-btn">Adopt</button>
            </Link>
          </div>

          <div className="pet-card">
            <img src="567.jpeg" alt="Max" />
            <h3>Max</h3>
            <p>3 years old, Labrador mix</p>
            <button className="adopt-btn">Adopt</button>
          </div>

          <div className="pet-card">
            <img src="a.jpeg" alt="Luna" />
            <h3>Luna</h3>
            <p>1 year old</p>
            <button className="adopt-btn">Adopt</button>
          </div>
        </div>
      </section>

      {/* Volunteer & Donation */}
      <section className="volunteer-donate">
        <div className="volunteer">
          <h2>Join as a Volunteer</h2>
          <Link to="/volunteer">
            <button className="volunteer-btn">Become a volunteer</button>
          </Link>
        </div>

        <div className="donate">
          <h2>Support Us by Donating</h2>
          <Link to="/donate">
            <button className="donate-btn">Donate</button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="footer">
        <div className="footer-left">
          <h2 className="logo">
            🏠 Adopt a Pet <span><br />Powered by Pedigree</span>
          </h2>
          <p>©2023 Mars or Affiliates.</p>
          <div className="social-icons">
            <a href="https://facebook.com" target="_blank" rel="noopener noreferrer"><FaFacebookF /></a>
            <a href="https://twitter.com" target="_blank" rel="noopener noreferrer"><FaTwitter /></a>
            <a href="https://instagram.com" target="_blank" rel="noopener noreferrer"><FaInstagram /></a>
          </div>
        </div>

        <div className="footer-links">
          <ul>
            <li><Link to="/home">Home</Link></li>
            <li><Link to="/adopt">Find a Pet</Link></li>
            <li><Link to="/faqs">Adoption FAQs</Link></li>
            <li><Link to="/follow-us">Follow Us</Link></li>
          </ul>

          <ul>
            <li><Link to="/partners">Partner Shelters & NGOs</Link></li>
            <li><Link to="/care">Caring For Pets</Link></li>
            <li><Link to="/about">About Us</Link></li>
          </ul>

          <ul>
            <li><Link to="/signup">Create an account</Link></li>
            <li><Link to="/login">Sign in</Link></li>
            <li><Link to="/contact">Contact Us</Link></li>
          </ul>

          <ul>
            <li><Link to="/mars">Visit Mars.com</Link></li>
            <li><Link to="/privacy">Privacy Statement</Link></li>
            <li><Link to="/legal">Legal</Link></li>
            <li><Link to="/ca-supply">CA Supply Chain Transparency Act</Link></li>
          </ul>

          <ul>
            <li><Link to="/modern-slavery">Modern Slavery Act</Link></li>
            <li><Link to="/accessibility">Accessibility</Link></li>
            <li><Link to="/cookies">Cookies Notice</Link></li>
            <li><Link to="/adchoices">AdChoices</Link></li>
          </ul>
        </div>

        <div className="cookie-btn">
          <button>Cookies Settings</button>
        </div>
      </footer>
    </div>
  );
}

export default Adopt;

import React, { useRef } from "react";
import "./Volunteer.css";

function Volunteer() {
  const applyRef = useRef(null);

  // Scroll function
  const scrollToForm = () => {
    if (applyRef.current) {
      applyRef.current.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <div className="volunteer-container">
      {/* Header Section */}
      <div className="volunteer-header">
        <div className="header-left">
          <h1>BECOME A VOLUNTEER</h1>
          <p>
            Join our team of passionate animal lovers and
            help make a difference in the lives of homeless pets.
          </p>
          <div className="tags">
            <span>Trusted</span>
            <span>Professional</span>
            <span>Award-winning</span>
          </div>
          {/* 🔹 Button with scroll */}
          <button className="btn-black" onClick={scrollToForm}>
            GET INVOLVED
          </button>
        </div>
        <div className="header-right">
          <img src="vol.jpg" alt="Volunteer with pet" />
        </div>
      </div>

      {/* Impact Section */}
      <div className="impact-section">
        <div>
          <h2>1,500+</h2>
          <p>Sheltered pets</p>
        </div>
        <div>
          <h2>2,300+</h2>
          <p>Volunteer hours</p>
        </div>
        <div>
          <h2>1,000+</h2>
          <p>Pets adopted</p>
        </div>
      </div>

      {/* Why Volunteer Section */}
      <div className="why-section">
        <h2>WHY VOLUNTEER</h2>
        <div className="why-cards">
          <div>
            <h3>Make a difference</h3>
            <p>
              Help improve the lives of homeless pets and offer them a chance
              for a better future.
            </p>
          </div>
          <div>
            <h3>Gain valuable experience</h3>
            <p>
              Develop new skills, learn about animal care, and gain real-world
              experience.
            </p>
          </div>
          <div>
            <h3>Connect with others</h3>
            <p>
              Join a supportive community of fellow animal lovers and make new
              friends.
            </p>
          </div>
        </div>
      </div>

      {/* How It Works Section */}
      <div className="how-section">
        <h2>HOW IT WORKS</h2>
        <div className="steps">
          <div>
            <h3>1 Apply</h3>
            <p>Fill out the volunteer application form.</p>
          </div>
          <div>
            <h3>2 Orientation</h3>
            <p>Attend a training session and learn more about our work.</p>
          </div>
        </div>
        <blockquote>
          "Volunteering has been an incredibly rewarding experience.  
          I’ve met amazing people and helped countless pets find their forever homes."
        </blockquote>
      </div>

      {/* Apply Now + FAQ */}
      <div ref={applyRef} className="bottom-section">
        <div className="apply-now">
          <h2>APPLY NOW</h2>
          <form>
            <input type="text" placeholder="Full Name" />
            <input type="email" placeholder="Email Address" />
            <button type="submit">Submit</button>
          </form>
        </div>
        <div className="faq">
          <h2>FREQUENTLY ASKED QUESTIONS</h2>
          <p>➕ What qualifications do I need to become a volunteer?</p>
        </div>
      </div>
    </div>
  );
}

export default Volunteer;

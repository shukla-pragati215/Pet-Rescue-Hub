import React from "react";
import { Link } from "react-router-dom";
import "./Pets.css";
import { FaFacebookF, FaTwitter, FaInstagram } from "react-icons/fa";

const petsData = [
  {
    id: 1,
    name: "Buddy",
    type: "Dog",
    age: "2 years",
    breed: "Labrador",
    image:
      "https://images.unsplash.com/photo-1558788353-f76d92427f16?fit=crop&w=400&q=80",
  },
  {
    id: 2,
    name: "Mittens",
    type: "Cat",
    age: "1 year",
    breed: "Siamese",
    image:
      "https://images.unsplash.com/photo-1592194996308-7b43878e84a6?fit=crop&w=400&q=80",
  },
  {
    id: 3,
    name: "Charlie",
    type: "Dog",
    age: "3 years",
    breed: "Beagle",
    image:
      "https://images.unsplash.com/photo-1598136492228-92b65e78aa2d?fit=crop&w=400&q=80",
  },
  {
    id: 4,
    name: "Luna",
    type: "Cat",
    age: "6 months",
    breed: "Persian",
    image:
      "https://images.unsplash.com/photo-1603316608481-4d1512e51233?fit=crop&w=400&q=80",
  },
];

function Pets() {
  return (
    <div className="app-container">
      {/* Navbar */}
      <nav className="navbar">
        <div className="nav-left">
          <Link to="/">Home</Link>
          <Link to="/adopt">Adopt a Pet</Link>
          <Link to="/lost-found">Lost & Found</Link>
          <Link to="/pet-doctors">Pet Doctors</Link>
          <Link to="/pet-care">Pet Care</Link>
        </div>

        <div className="nav-right">
          <Link to="/login" className="login-link">
            Login
          </Link>
          <Link to="/signup" className="signup-btn">
            Sign Up
          </Link>
        </div>
      </nav>

      {/* Main Content */}
      <div className="pets-container">
        <h1 className="title">Available Pets for Adoption</h1>
        <p className="subtitle">Find your new furry friend today!</p>

        <div className="pets-grid">
          {petsData.map((pet) => (
            <div key={pet.id} className="pet-card">
              <img src={pet.image} alt={pet.name} />
              <h3>{pet.name}</h3>
              <p>Type: {pet.type}</p>
              <p>Breed: {pet.breed}</p>
              <p>Age: {pet.age}</p>

              <Link to={`/adopt/${pet.id}`}>
                <button className="adopt-btn">Adopt Now</button>
              </Link>
            </div>
          ))}
        </div>
      </div>

      {/* Footer */}
      <footer className="footer">
        <div className="footer-left">
          <h2 className="logo">
            🏠 Adopt a Pet <span>Powered by Pedigree</span>
          </h2>
          <p>©2023 Mars or Affiliates.</p>

          <div className="social-icons">
            <a
              href="https://facebook.com"
              target="_blank"
              rel="noopener noreferrer"
            >
              <FaFacebookF />
            </a>
            <a
              href="https://twitter.com"
              target="_blank"
              rel="noopener noreferrer"
            >
              <FaTwitter />
            </a>
            <a
              href="https://instagram.com"
              target="_blank"
              rel="noopener noreferrer"
            >
              <FaInstagram />
            </a>
          </div>
        </div>

        <div className="footer-links">
          <ul>
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/adopt">Find a Pet</Link>
            </li>
            <li>
              <Link to="/faqs">Adoption Faqs</Link>
            </li>
            <li>
              <Link to="/follow-us">Follow Us</Link>
            </li>
          </ul>

          <ul>
            <li>
              <Link to="/partners">Partner Shelters & NGOs</Link>
            </li>
            <li>
              <Link to="/care">Caring For Pets</Link>
            </li>
            <li>
              <Link to="/about">About Us</Link>
            </li>
          </ul>

          <ul>
            <li>
              <Link to="/signup">Create an account</Link>
            </li>
            <li>
              <Link to="/login">Sign in</Link>
            </li>
            <li>
              <Link to="/contact">Contact Us</Link>
            </li>
          </ul>

          <ul>
            <li>
              <Link to="/mars">Visit Mars.com</Link>
            </li>
            <li>
              <Link to="/privacy">Privacy Statement</Link>
            </li>
            <li>
              <Link to="/legal">Legal</Link>
            </li>
            <li>
              <Link to="/ca-supply">CA Supply Chain Transparency Act</Link>
            </li>
          </ul>

          <ul>
            <li>
              <Link to="/modern-slavery">Modern Slavery Act</Link>
            </li>
            <li>
              <Link to="/accessibility">Accessibility</Link>
            </li>
            <li>
              <Link to="/cookies">Cookies Notice</Link>
            </li>
            <li>
              <Link to="/adchoices">AdChoices</Link>
            </li>
          </ul>
        </div>

        <div className="cookie-btn">
          <button>Cookies Settings</button>
        </div>
      </footer>
    </div>
  );
}

export default Pets;

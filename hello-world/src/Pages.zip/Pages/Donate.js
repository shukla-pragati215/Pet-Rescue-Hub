// Donate.js
import React from "react";
import "./Donate.css";
import { useNavigate, Link } from "react-router-dom";

function Donate() {
  const navigate = useNavigate();

  return (
    <div className="adopt-container">

      {/* Navbar */}
      <nav className="navbar">
        <div className="nav-left">
          <Link to="/">Home</Link>
          <Link to="/adopt">Adopt a Pet</Link>
          <Link to="/lost-found">Lost & Found</Link>
          <Link to="/pet-doctors">Pet Doctors</Link>
          <Link to="/pet-care">Pet Care</Link>
        </div>

        <div className="nav-right">
          <Link to="/login" className="login-link">Login</Link>
          <Link to="/signup" className="signup-btn">Sign Up</Link>
        </div>
      </nav>

      {/* Content */}
      <div className="donate-container">
        
        {/* Image & Heading */}
        <div className="donate-hero">
          <img
            src="donate.jpg"
            alt="Donate"
            className="donate-image"
          />
          <h2>Support Us By Donating</h2>
          <p>Your Love Saves Lives</p>
        </div>

        {/* Options */}
        <div className="donate-options">
          <div className="donate-card">
            <img src="https://img.icons8.com/ios-filled/100/home.png" alt="Shelter" />
            <p>SHELTER</p>
          </div>

          <div className="donate-card">
            <img src="https://img.icons8.com/ios-filled/100/meal.png" alt="Food" />
            <p>FOOD</p>
          </div>

          <div className="donate-card">
            <img src="https://img.icons8.com/ios-filled/100/hospital-room.png" alt="Healthcare" />
            <p>HEALTHCARE</p>
          </div>

          <div className="donate-card">
            <img src="https://img.icons8.com/ios-filled/100/like.png" alt="Adoption" />
            <p>ADOPTION</p>
          </div>
        </div>

        {/* Donate Button */}
        <button onClick={() => navigate("/donate-page")} className="donate-btn">
          DONATE NOW
        </button>

        {/* Footer */}
        <footer className="lostfound-footer">
          <a href="/">Home</a>
          <a href="/contact">Contact</a>
          <a href="/policy">Privacy Policy</a>
        </footer>

      </div>
    </div>
  );
}

export default Donate;

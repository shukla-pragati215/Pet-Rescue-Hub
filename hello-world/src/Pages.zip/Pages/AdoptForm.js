import React, { useState } from "react";
import { useParams, Link } from "react-router-dom";
import "./AdoptForm.css";

const petsData = [
  {
    id: 1,
    name: "Buddy",
    type: "Dog",
    age: "2 years",
    breed: "Labrador",
    image: "https://images.unsplash.com/photo-1558788353-f76d92427f16?fit=crop&w=400&q=80",
  },
  {
    id: 2,
    name: "Mittens",
    type: "Cat",
    age: "1 year",
    breed: "Siamese",
    image: "https://images.unsplash.com/photo-1592194996308-7b43878e84a6?fit=crop&w=400&q=80",
  },
  {
    id: 3,
    name: "Charlie",
    type: "Dog",
    age: "3 years",
    breed: "Beagle",
    image: "https://images.unsplash.com/photo-1598136492228-92b65e78aa2d?fit=crop&w=400&q=80",
  },
  {
    id: 4,
    name: "Luna",
    type: "Cat",
    age: "6 months",
    breed: "Persian",
    image: "https://images.unsplash.com/photo-1603316608481-4d1512e51233?fit=crop&w=400&q=80",
  },
];

function AdoptForm() {
  const { id } = useParams();
  const pet = petsData.find((p) => p.id === parseInt(id));

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    address: "",
    message: "",
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert(`Thank you ${formData.name}! Your adoption request for ${pet.name} has been submitted.`);
    setFormData({ name: "", email: "", address: "", message: "" });
  };

  if (!pet) {
    return <p>Pet not found.</p>;
  }

  return (
    <div className="adopt-container">

      {/* Navbar */}
      <nav className="navbar">
        <div className="nav-left">
          <Link to="/">Home</Link>
          <Link to="/adopt">Adopt a Pet</Link>
          <Link to="/lost-found">Lost & Found</Link>
          <Link to="/pet-doctors">Pet Doctors</Link>
          <Link to="/pet-care">Pet Care</Link>
        </div>

        <div className="nav-right">
          <Link to="/login" className="login-link">Login</Link>
          <Link to="/signup" className="signup-btn">Sign Up</Link>
        </div>
      </nav>

      {/* Main Form Content */}
      <div className="adoptform-container">
        <h1>Adopt {pet.name}</h1>

        <div className="pet-details">
          <img src={pet.image} alt={pet.name} />
          <div className="pet-info">
            <p><strong>Type:</strong> {pet.type}</p>
            <p><strong>Breed:</strong> {pet.breed}</p>
            <p><strong>Age:</strong> {pet.age}</p>
          </div>
        </div>

        <h2>Fill Adoption Form</h2>

        <form onSubmit={handleSubmit}>
          <input
            type="text"
            name="name"
            placeholder="Your Name"
            value={formData.name}
            onChange={handleChange}
            required
          />

          <input
            type="email"
            name="email"
            placeholder="Your Email"
            value={formData.email}
            onChange={handleChange}
            required
          />

          <input
            type="text"
            name="address"
            placeholder="Your Address"
            value={formData.address}
            onChange={handleChange}
            required
          />

          <textarea
            name="message"
            placeholder="Message (optional)"
            value={formData.message}
            onChange={handleChange}
          ></textarea>

          <button type="submit" className="submit-btn">Submit Request</button>
        </form>

        <Link to="/pets" className="back-link">← Back to Pets</Link>

        {/* Footer */}
        <footer className="lostfound-footer">
          <a href="/">Home</a>
          <a href="/contact">Contact</a>
          <a href="/policy">Privacy Policy</a>
        </footer>
      </div>
    </div>
  );
}

export default AdoptForm;

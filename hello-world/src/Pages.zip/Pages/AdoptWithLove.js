import React from "react";
import { useNavigate, Link } from "react-router-dom";
import "./AdoptWithLove.css";

function AdoptWithLove() {
  const navigate = useNavigate();

  return (
    <div className="adopt-container">

      {/* Navbar */}
      <nav className="navbar">
        <div className="nav-left">
          <Link to="/">Home</Link>
          <Link to="/adopt">Adopt a Pet</Link>
          <Link to="/lost-found">Lost & Found</Link>
          <Link to="/pet-doctors">Pet Doctors</Link>
          <Link to="/pet-care">Pet Care</Link>
        </div>

        <div className="nav-right">
          <Link to="/login" className="login-link">Login</Link>
          <Link to="/signup" className="signup-btn">Sign Up</Link>
        </div>
      </nav>

      <div className="adoptlove-container">

        {/* Top Image */}
        <img
          src="love.png"    // Make sure love.png is inside public/ folder
          alt="Adopt with Love"
          className="adoptlove-image"
        />

        {/* Title */}
        <h2 className="adoptlove-title">Adopt with Love</h2>

        {/* Description */}
        <p className="adoptlove-desc">
          Every adoption is an act of love. When you adopt, you give a pet a
          second chance at life and gain a lifelong friend.
        </p>

        {/* Cards */}
        <div className="adoptlove-cards">
          <div className="adoptlove-card">
            <img
              src="https://img.icons8.com/ios-filled/100/000000/home.png"
              alt="Give a Home"
            />
            <p>Give a Home</p>
          </div>

          <div className="adoptlove-card">
            <img
              src="https://img.icons8.com/ios-filled/100/fa314a/like.png"
              alt="Share Love"
            />
            <p>Share Love</p>
          </div>

          <div className="adoptlove-card">
            <img
              src="https://img.icons8.com/ios-filled/100/d35400/dog.png"
              alt="Save a Life"
            />
            <p>Save a Life</p>
          </div>
        </div>

        {/* Button */}
        <button
          className="adoptlove-btn"
          onClick={() => navigate("/adoption")} // make sure route exists
        >
          Adopt Now
        </button>

        {/* Footer */}
        <footer className="lostfound-footer">
          <a href="/">Home</a>
          <a href="/contact">Contact</a>
          <a href="/policy">Privacy Policy</a>
        </footer>
        
      </div>
    </div>
  );
}

export default AdoptWithLove;

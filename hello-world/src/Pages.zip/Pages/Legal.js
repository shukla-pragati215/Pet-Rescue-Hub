import React from "react";
import "./Legal.css";
import { Link } from "react-router-dom";

function Legal() {
  return (
    <div>
      {/* ✅ Navbar */}
      <nav className="navbar">
        <div className="nav-left">
          <Link to="/">Home</Link>
          <Link to="/adopt">Adopt a Pet</Link>
          <Link to="/lost-found">Lost & Found</Link>
          <Link to="/pet-doctors">Pet Doctors</Link>
          <Link to="/pet-care">Pet Care</Link>
        </div>

        <div className="nav-right">
          <Link to="/login" className="login-link">Login</Link>
          <Link to="/signup" className="signup-btn">Sign Up</Link>
        </div>
      </nav>

      {/* ✅ Legal Content */}
      <div className="legal-content">
        <h1>📜 Legal Notice</h1>
        <p>
          Welcome to <strong>Pet Rescue Hub</strong>. By using this website, you
          agree to the following terms and conditions.
        </p>

        <h3>1️⃣ Ownership and Copyright</h3>
        <p>
          All content, images, and designs on this website are the property of
          Pet Rescue Hub and protected under copyright laws.
        </p>

        <h3>2️⃣ Use of Content</h3>
        <p>
          You may view and download materials for personal use only.
          Reproduction, distribution, or modification without permission is
          prohibited.
        </p>

        <h3>3️⃣ Disclaimer</h3>
        <p>
          Pet Rescue Hub provides information “as is.” We make no guarantees
          regarding accuracy or availability of pets listed.
        </p>

        <h3>4️⃣ Liability</h3>
        <p>
          We are not responsible for any direct or indirect damages arising from
          the use of this website.
        </p>

        <h3>5️⃣ Updates</h3>
        <p>
          We may modify this legal notice at any time. Please review this page
          periodically for updates.
        </p>
      </div>

      {/* Footer */}
      <footer className="lostfound-footer">
        <a href="/">Home</a>
        <a href="/contact">Contact</a>
        <a href="/policy">Privacy Policy</a>
      </footer>
    </div>
  );
}

export default Legal;

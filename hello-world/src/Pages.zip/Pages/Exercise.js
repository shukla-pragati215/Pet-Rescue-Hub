import React from "react";
import { Link } from "react-router-dom";
import "./Exercise.css";

function Exercise() {
  return (
    <div className="adopt-container">

      {/* Navbar */}
      <nav className="navbar">
        <div className="nav-left">
          <Link to="/">Home</Link>
          <Link to="/adopt">Adopt a Pet</Link>
          <Link to="/lost-found">Lost & Found</Link>
          <Link to="/pet-doctors">Pet Doctors</Link>
          <Link to="/pet-care">Pet Care</Link>
        </div>

        <div className="nav-right">
          <Link to="/login" className="login-link">Login</Link>
          <Link to="/signup" className="signup-btn">Sign Up</Link>
        </div>
      </nav>

      <div className="exercise-container">

        {/* Header */}
        <h1 className="title">Pet Exercise</h1>
        <p className="subtitle">Keep your pet active, strong, and happy</p>

        {/* Image */}
        <div className="image-container">
          <img
            src="training.jpg"
            alt="Pet exercising outdoors"
            className="exercise-image"
          />
        </div>

        {/* Info Section */}
        <div className="exercise-info">
          <h2>🏃 Why Exercise is Important?</h2>
          <p>
            Regular exercise keeps pets physically fit, prevents obesity, reduces stress,
            and improves overall health. It also strengthens the bond between pets
            and their owners.
          </p>

          <h2>💡 Types of Exercises</h2>
          <ul>
            <li>🐕 Daily walks to keep them active</li>
            <li>🎾 Playing fetch for stimulation</li>
            <li>🏠 Indoor games during bad weather</li>
            <li>🏋️ Agility training for active breeds</li>
            <li>🌳 Social playtime with other pets</li>
          </ul>

          <h2>📅 Exercise Schedule</h2>
          <table className="exercise-table">
            <thead>
              <tr>
                <th>Pet Type</th>
                <th>Recommended Exercise</th>
                <th>Duration</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Puppies</td>
                <td>Short walks + playtime</td>
                <td>15–20 min (2–3 times/day)</td>
              </tr>
              <tr>
                <td>Adult Dogs</td>
                <td>Walks + running + games</td>
                <td>30–60 min daily</td>
              </tr>
              <tr>
                <td>Cats</td>
                <td>Interactive toys + climbing</td>
                <td>15–30 min daily</td>
              </tr>
              <tr>
                <td>Senior Pets</td>
                <td>Gentle walks + light play</td>
                <td>10–20 min daily</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Footer */}
      <footer className="lostfound-footer">
        <Link to="/">Home</Link>
        <Link to="/contact">Contact</Link>
        <Link to="/policy">Privacy Policy</Link>
      </footer>
    </div>
  );
}

export default Exercise;

import React from "react";
import "./homepage.css";
import { Link } from "react-router-dom";


// Example icons (you can replace with your own images or use react-icons)
const menuLeft = [
  { name: "Adopt a Pet", icon: "https://cdn-icons-png.flaticon.com/512/616/616408.png" },
  { name: "Rehome a Pet", icon: "https://cdn-icons-png.flaticon.com/512/616/616408.png" },
  { name: "Lost & Found", icon: "https://cdn-icons-png.flaticon.com/512/565/565547.png" },
  { name: "About Us", icon: "https://cdn-icons-png.flaticon.com/512/1077/1077063.png" },
];

const menuRight = [
  { name: "Nearby vet", icon: "https://cdn-icons-png.flaticon.com/512/616/616408.png" },
  { name: "Nearby Shop", icon: "https://cdn-icons-png.flaticon.com/512/3144/3144456.png" },
  { name: "Pet Care", icon: "https://cdn-icons-png.flaticon.com/512/616/616408.png" },
  { name: "Blog", icon: "https://cdn-icons-png.flaticon.com/512/3037/3037266.png" },
];

export default function PetRescueHub() {
  return (
    <div className="min-h-screen bg-blue-600 text-white">
      {/* Navbar */}
      <nav className="flex justify-between items-center px-6 py-3 bg-white text-blue-700 shadow">
        <div className="flex space-x-6">
          <Link to="/">Home</Link>
          <Link to="/adopt">Adopt a Pet</Link>
          <Link to="/lost">Lost & Found</Link>
          <Link to="/doctors">Pet Doctors</Link>
          <Link to="/care">Pet Care</Link>
        </div>
        <div className="space-x-4">
          <Link to="/login" className="hover:underline">
            Login
          </Link>
          <Link
            to="/signup"
            className="hover:underline text-gray-400 cursor-not-allowed"
          >
            Sign Up
          </Link>
        </div>
      </nav>

      {/* Main Content */}
      <div className="flex px-12 py-8">
        {/* Left Menu */}
        <div className="w-1/2">
          <h2 className="text-2xl font-bold mb-4">Pet Rescue Hub</h2>
          <ul className="space-y-3">
            {menuLeft.map((item, index) => (
              <li key={index} className="flex items-center space-x-3">
                <img src={item.icon} alt={item.name} className="w-6 h-6" />
                <span>{item.name}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Divider */}
        <div className="w-1 bg-red-500 mx-8"></div>

        {/* Right Menu */}
        <div className="w-1/2">
          <ul className="space-y-3 mt-10">
            {menuRight.map((item, index) => (
              <li key={index} className="flex items-center space-x-3">
                <img src={item.icon} alt={item.name} className="w-6 h-6" />
                <span>{item.name}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}

import React, { useState } from "react";
import "./DonatePage.css";
import { Link } from "react-router-dom";

function DonatePage() {
  const [amount, setAmount] = useState("");
  const [purpose, setPurpose] = useState("");
  const [donor, setDonor] = useState({ name: "", email: "", phone: "" });

  const handleAmountClick = (value) => {
    setAmount(value);
  };

  const handlePurposeClick = (value) => {
    setPurpose(value);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setDonor({ ...donor, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log({ amount, purpose, donor });
    alert("Donation Completed!");
  };

  return (
    <div className="adopt-container">

      {/* Navbar */}
      <nav className="navbar">
        <div className="nav-left">
          <Link to="/">Home</Link>
          <Link to="/adopt">Adopt a Pet</Link>
          <Link to="/lost-found">Lost & Found</Link>
          <Link to="/pet-doctors">Pet Doctors</Link>
          <Link to="/pet-care">Pet Care</Link>
        </div>

        <div className="nav-right">
          <Link to="/login" className="login-link">Login</Link>
          <Link to="/signup" className="signup-btn">Sign Up</Link>
        </div>
      </nav>

      {/* Main Donate Section */}
      <div className="donate-container">
        <h1>Make a Difference Today</h1>
        <p>Your donation helps provide food, shelter, and care for homeless animals.</p>

        {/* Amount Selector */}
        <div className="amount-section">
          {[100, 250, 500, 1000].map((value) => (
            <button
              key={value}
              className={`amount-btn ${amount === value ? "active" : ""}`}
              onClick={() => handleAmountClick(value)}
            >
              ₹ {value}
            </button>
          ))}

          <input
            type="number"
            placeholder="₹ Custom amount"
            value={
              amount && ![100, 250, 500, 1000].includes(amount)
                ? amount
                : ""
            }
            onChange={(e) => setAmount(Number(e.target.value))}
          />
        </div>

        {/* Purpose */}
        <h2>Donation Purpose</h2>
        <div className="purpose-section">
          {[
            { label: "FOOD", icon: "🍲" },
            { label: "SHELTER", icon: "🏠" },
            { label: "HEALTHCARE", icon: "➕" },
            { label: "ADOPTION", icon: "❤️" },
          ].map((item) => (
            <button
              key={item.label}
              className={`purpose-btn ${
                purpose === item.label ? "active" : ""
              }`}
              onClick={() => handlePurposeClick(item.label)}
            >
              <span className="icon">{item.icon}</span>
              {item.label}
            </button>
          ))}
        </div>

        {/* Donor Form */}
        <h2>Donor Information</h2>
        <form onSubmit={handleSubmit} className="donor-form">
          <input
            type="text"
            name="name"
            placeholder="Name"
            value={donor.name}
            onChange={handleInputChange}
            required
          />

          <input
            type="email"
            name="email"
            placeholder="Email"
            value={donor.email}
            onChange={handleInputChange}
            required
          />

          <input
            type="tel"
            name="phone"
            placeholder="Phone"
            value={donor.phone}
            onChange={handleInputChange}
            required
          />

          <div className="payment-methods">
            <span>₹ UPI / Paytm / GPay</span>
            <span>💳 Debit/Credit Card</span>
          </div>

          <button type="submit" className="complete-btn">
            COMPLETE DONATION
          </button>
        </form>
      </div>
    </div>
  );
}

export default DonatePage;

import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import "./AdoptNowPage.css";

function AdoptNowPage() {
  const [submitted, setSubmitted] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
  };

  const handleClose = () => {
    navigate("/"); 
  };

  return (
    <div className="adopt-container">

      {/* Navbar */}
      <nav className="navbar">
        <div className="nav-left">
          <Link to="/">Home</Link>
          <Link to="/adopt">Adopt a Pet</Link>
          <Link to="/lost-found">Lost & Found</Link>
          <Link to="/pet-doctors">Pet Doctors</Link>
          <Link to="/pet-care">Pet Care</Link>
        </div>

        <div className="nav-right">
          <Link to="/login" className="login-link">Login</Link>
          <Link to="/signup" className="signup-btn">Sign Up</Link>
        </div>
      </nav>

      {/* Form Section */}
      <div className="form-container">
        <h2>Adoption Application Form</h2>

        {submitted ? (
          <div className="thankyou-popup">
            <div className="thankyou-content">
              <h3>🎉 Thank you for your application!</h3>
              <p>Our team will review your details and get in touch with you soon.</p>
              <button onClick={handleClose} className="close-btn">Close</button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit}>
            <label>Full Name</label>
            <input type="text" placeholder="Enter your full name" required />

            <label>Email</label>
            <input type="email" placeholder="Enter your email" required />

            <label>Phone Number</label>
            <input type="tel" placeholder="Enter your phone number" required />

            <label>Address</label>
            <textarea placeholder="Enter your full address" required></textarea>

            <label>Pet Preference</label>
            <select required>
              <option value="">-- Select Pet --</option>
              <option value="dog">Dog</option>
              <option value="cat">Cat</option>
              <option value="other">Other</option>
            </select>

            <label>Why do you want to adopt?</label>
            <textarea placeholder="Write your reason..." required></textarea>

            <button type="submit" className="submit-btn">
              Submit Application
            </button>
          </form>
        )}
      </div>

      {/* Footer */}
      <footer className="lostfound-footer">
        <a href="/">Home</a>
        <a href="/contact">Contact</a>
        <a href="/policy">Privacy Policy</a>
      </footer>
    </div>
  );
}

export default AdoptNowPage;

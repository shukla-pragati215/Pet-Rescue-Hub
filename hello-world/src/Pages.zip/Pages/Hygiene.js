import React, { useState } from "react";
import { Link } from "react-router-dom";
import "./Hygiene.css"; // Make sure this file exists!

const Hygiene = () => {
  const [selectedProduct, setSelectedProduct] = useState(null);

  const products = [
    { id: 1, name: "🐶 Pet Shampoo", price: "₹350", desc: "Gentle, pet-friendly shampoo for soft and clean fur." },
    { id: 2, name: "🦷 Dog Toothpaste & Brush Kit", price: "₹250", desc: "Keep your pet’s teeth clean and healthy." },
    { id: 3, name: "🧴 Flea & Tick Spray", price: "₹500", desc: "Protects your pet from fleas and ticks effectively." },
    { id: 4, name: "🪮 Grooming Brush", price: "₹400", desc: "Perfect for removing loose fur and tangles." },
    { id: 5, name: "✂️ Nail Clipper", price: "₹300", desc: "Safe and easy to trim your pet’s nails." },
  ];

  return (
    <div className="adopt-container">
      
      {/* Navbar */}
      <nav className="navbar">
        <div className="nav-left">
          <Link to="/">Home</Link>
          <Link to="/adopt">Adopt a Pet</Link>
          <Link to="/lost-found">Lost & Found</Link>
          <Link to="/pet-doctors">Pet Doctors</Link>
          <Link to="/pet-care">Pet Care</Link>
        </div>
        <div className="nav-right">
          <Link to="/login" className="login-link">Login</Link>
          <Link to="/signup" className="signup-btn">Sign Up</Link>
        </div>
      </nav>

      {/* Main Content */}
      <div className="hygiene-container">
        <h1 className="title">Pet Hygiene</h1>
        <p className="subtitle">Keep your pet clean, healthy and happy</p>

        <div className="image-container">
          {/* Change src to /hygiene.png if image is inside public folder */}
          <img src="/hygiene.png" alt="Pet Hygiene" className="hygiene-image" />
        </div>

        {/* Hygiene Tips */}
        <div className="hygiene-tips">
          <h2>Why Hygiene is Important</h2>
          <p>
            Good hygiene helps prevent diseases, parasites, and discomfort in pets.
            Regular grooming also helps build trust between you and your pet.
          </p>

          <h2>Basic Hygiene Tips</h2>
          <ul>
            <li>🛁 Bathe your pet regularly using pet-friendly shampoo</li>
            <li>🧼 Clean ears to prevent infections</li>
            <li>🪥 Brush their teeth to avoid dental issues</li>
            <li>✂️ Trim nails to prevent overgrowth and pain</li>
            <li>🧴 Use flea and tick treatments as needed</li>
          </ul>

          <h2>Grooming Schedule</h2>
          <table className="hygiene-table">
            <thead>
              <tr>
                <th>Activity</th>
                <th>Frequency</th>
              </tr>
            </thead>
            <tbody>
              <tr><td>Bathing</td><td>Once every 2–4 weeks</td></tr>
              <tr><td>Brushing</td><td>2–3 times a week</td></tr>
              <tr><td>Nail Trimming</td><td>Every 3–4 weeks</td></tr>
              <tr><td>Ear Cleaning</td><td>Once a month</td></tr>
              <tr><td>Teeth Brushing</td><td>2–3 times a week</td></tr>
            </tbody>
          </table>
        </div>

        {/* Prices & Products */}
        <div className="price-section">
          <h2>💲 Grooming & Hygiene Services Price List</h2>

          <table className="price-table">
            <thead>
              <tr>
                <th>Service</th>
                <th>Price (₹)</th>
              </tr>
            </thead>
            <tbody>
              <tr><td>Full Grooming (Bath + Haircut + Nail Trim)</td><td>1500</td></tr>
              <tr><td>Bath & Blow Dry</td><td>800</td></tr>
              <tr><td>Nail Trimming</td><td>300</td></tr>
              <tr><td>Ear Cleaning</td><td>400</td></tr>
              <tr><td>Teeth Cleaning</td><td>600</td></tr>
              <tr><td>Anti-Tick/Flea Treatment</td><td>1000</td></tr>
            </tbody>
          </table>

          <h3>🛒 Pet Hygiene Products</h3>

          <div className="product-list">
            {products.map((p) => (
              <div
                key={p.id}
                className="product-card"
                onClick={() => setSelectedProduct(p)}
              >
                <h3>{p.name}</h3>
                <p>{p.price}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Product Modal */}
      {selectedProduct && (
        <div className="modal-overlay" onClick={() => setSelectedProduct(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h2>{selectedProduct.name}</h2>
            <p><strong>Price:</strong> {selectedProduct.price}</p>
            <p>{selectedProduct.desc}</p>
            <button className="close-btn" onClick={() => setSelectedProduct(null)}>Close</button>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="lostfound-footer">
        <a href="/">Home</a>
        <a href="/contact">Contact</a>
        <a href="/policy">Privacy Policy</a>
      </footer>

    </div>
  );
};

export default Hygiene;
